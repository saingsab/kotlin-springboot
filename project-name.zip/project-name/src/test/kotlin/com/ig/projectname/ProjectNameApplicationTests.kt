package com.ig.projectname

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ProjectNameApplicationTests {

	@Test
	fun contextLoads() {
	}

}
